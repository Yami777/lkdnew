<template>
  <div>
    工作量列表
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
