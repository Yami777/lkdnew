<template>
  <div>
    商品类型
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
