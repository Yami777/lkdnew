<template>
  <div>
    合作商管理
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
