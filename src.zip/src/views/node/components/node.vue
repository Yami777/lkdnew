<template>
  <div>
    点位管理
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
