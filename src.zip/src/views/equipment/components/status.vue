<template>
  <div>
    设备状态
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
